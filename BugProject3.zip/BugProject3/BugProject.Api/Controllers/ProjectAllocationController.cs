﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProjectAllocationController : Controller
    {
        private readonly IProjectAllocationService projectAllocationService;
        private readonly IMapper mapper;

        public ProjectAllocationController(IProjectAllocationService projectAllocationService, IMapper mapper)
        {
            this.projectAllocationService = projectAllocationService;
            this.mapper = mapper;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllProjectAllocationsAsync()
        {
            var projectAllocations = await projectAllocationService.GetAllAsync();


            var projectAllocationsDTO = new List<Infrastructure.Persistence.DTO.ProjectAllocation>();
            projectAllocations.ToList().ForEach(projectAllocation =>
            {
                var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation()
                {
                    AllocationID = projectAllocation.AllocationID,
                    ProjectID = projectAllocation.ProjectID,
                    UserID = projectAllocation.UserID,                   
                    UpdatedOn = projectAllocation.UpdatedOn,
                    UpdatedBy = projectAllocation.UpdatedBy,

                };
                projectAllocationsDTO.Add(projectAllocationDTO);
            });


            return Ok(projectAllocationsDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetProjectAllocationAsync")]
        public async Task<IActionResult> GetProjectAllocationAsync(Guid id)
        {
            var projectAllocation = await projectAllocationService.GetAsync(id);

            if (projectAllocation == null)
            {
                return NotFound();
            }

            var projectAllocations = await projectAllocationService.GetAllAsync();
            var projectAllocationsDTO = new List<Infrastructure.Persistence.DTO.ProjectAllocation>();
            projectAllocations.ToList().ForEach(projectAllocation =>
            {
                if (projectAllocation.AllocationID == id)
                {
                    var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation()
                    {
                        AllocationID = projectAllocation.AllocationID,
                        ProjectID = projectAllocation.ProjectID,
                        UserID = projectAllocation.UserID,
                        UpdatedOn = projectAllocation.UpdatedOn,
                        UpdatedBy = projectAllocation.UpdatedBy,

                    };
                    projectAllocationsDTO.Add(projectAllocationDTO);
                }
            });
            return Ok(projectAllocationsDTO);
        }

        [HttpPost]

        public async Task<IActionResult> AddProjectAllocationAsync(Infrastructure.Persistence.DTO.AddProjectAllocationRequest addProjectAllocationRequest)
        {

            var projectAllocation = new Domain.Entities.ProjectAllocation()
            {
                ProjectID = addProjectAllocationRequest.ProjectID,
                UserID = addProjectAllocationRequest.UserID,
                UpdatedOn = addProjectAllocationRequest.UpdatedOn,
                UpdatedBy = addProjectAllocationRequest.UpdatedBy,
            };

            // Pass details to Service
            projectAllocation = await projectAllocationService.AddAsync(projectAllocation);

            // Convert back to DTO

            var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
            {
                AllocationID = projectAllocation.AllocationID,
                ProjectID = projectAllocation.ProjectID,
                UserID = projectAllocation.UserID,
                UpdatedOn = projectAllocation.UpdatedOn,
                UpdatedBy = projectAllocation.UpdatedBy,
            };

            return CreatedAtAction(nameof(GetProjectAllocationAsync), new { id = projectAllocationDTO.AllocationID }, projectAllocationDTO);
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteProjectAllocationAsync(Guid id)
        {
            // Get projectAllocation from database
            var projectAllocation = await projectAllocationService.DeleteAsync(id);

            // If null NotFound
            if (projectAllocation == null)
            {
                return NotFound();
            }

            // Convert response back to DTO
            var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
            {
                AllocationID = projectAllocation.AllocationID,
                ProjectID = projectAllocation.ProjectID,
                UserID = projectAllocation.UserID,
                UpdatedOn = projectAllocation.UpdatedOn,
                UpdatedBy = projectAllocation.UpdatedBy,
            };


            // return Ok response
            return Ok(projectAllocationDTO);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateProjectAllocationAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateProjectAllocationRequest updateProjectAllocationRequest)
        {

            var projectAllocation = new Domain.Entities.ProjectAllocation()
            {
                ProjectID = updateProjectAllocationRequest.ProjectID,
                UserID = updateProjectAllocationRequest.UserID,

            };


            // Update Region using Service
            projectAllocation = await projectAllocationService.UpdateAsync(id, projectAllocation);


            // If Null then NotFound
            if (projectAllocation == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
            {
                AllocationID = projectAllocation.AllocationID,
                ProjectID = projectAllocation.ProjectID,
                UserID = projectAllocation.UserID,
                UpdatedOn = projectAllocation.UpdatedOn,
                UpdatedBy = projectAllocation.UpdatedBy,
            };


            // Return Ok response
            return Ok(projectAllocationDTO);
        }


    }
}
