﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly IUserService userService;
        private readonly IMapper mapper;

        public UserController(IUserService userService, IMapper mapper)
        {
            this.userService = userService;
            this.mapper = mapper;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllUsersAsync()
        {
            var users = await userService.GetAllAsync();


            var usersDTO = new List<Infrastructure.Persistence.DTO.User>();
            users.ToList().ForEach(user =>
            {
                var userDTO = new Infrastructure.Persistence.DTO.User()
                {
                    UserID = user.UserID,
                    UserName= user.UserName,
                    Password= user.Password,
                    RoleID= user.RoleID,
                    UpdatedBy = user.UpdatedBy,
                    UpdatedOn = user.UpdatedOn,

                };
                usersDTO.Add(userDTO);
            });


            return Ok(usersDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetUserAsync")]
        public async Task<IActionResult> GetUserAsync(Guid id)
        {
            var user = await userService.GetAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            var users = await userService.GetAllAsync();
            var usersDTO = new List<Infrastructure.Persistence.DTO.User>();
            users.ToList().ForEach(user =>
            {
                if (user.UserID == id)
                {
                    var userDTO = new Infrastructure.Persistence.DTO.User()
                    {
                        UserID = user.UserID,
                        UserName = user.UserName,
                        Password= user.Password,
                        RoleID= user.RoleID,
                        UpdatedBy = user.UpdatedBy,
                        UpdatedOn = user.UpdatedOn,

                    };
                    usersDTO.Add(userDTO);
                }
            });
            return Ok(usersDTO);
        }

        [HttpPost]

        public async Task<IActionResult> AddUserAsync(Infrastructure.Persistence.DTO.AddUserRequest addUserRequest)
        {

            var user = new Domain.Entities.User()
            {
                UserName= addUserRequest.UserName, 
                Password= addUserRequest.Password,
                UpdatedBy = addUserRequest.UpdatedBy,


                UpdatedOn = addUserRequest.UpdatedOn,
            };

            // Pass details to Service
            user = await userService.AddAsync(user);

            // Convert back to DTO

            var userDTO = new Infrastructure.Persistence.DTO.User
            {
                UserID = user.UserID,
                UserName= user.UserName,
                Password= user.Password,
                UpdatedBy = user.UpdatedBy,

                UpdatedOn = user.UpdatedOn,
            };

            return CreatedAtAction(nameof(GetUserAsync), new { id = userDTO.UserID }, userDTO);
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteUserAsync(Guid id)
        {
            // Get user from database
            var user = await userService.DeleteAsync(id);

            // If null NotFound
            if (user == null)
            {
                return NotFound();
            }

            // Convert response back to DTO
            var userDTO = new Infrastructure.Persistence.DTO.User
            {
                UserID = user.UserID,
                UserName= user.UserName,
                UpdatedBy = user.UpdatedBy,

                UpdatedOn = user.UpdatedOn,
            };


            // return Ok response
            return Ok(userDTO);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateUserAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateUserRequest updateUserRequest)
        {

            var user = new Domain.Entities.User()
            {
                UserName = updateUserRequest.UserName,
                Password = updateUserRequest.Password,
                UpdatedBy = updateUserRequest.UpdatedBy,
                UpdatedOn = updateUserRequest.UpdatedOn,

            };


            // Update Region using Service
            user = await userService.UpdateAsync(id, user);


            // If Null then NotFound
            if (user == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var userDTO = new Infrastructure.Persistence.DTO.User
            {
                UserID = user.UserID,
                UserName= user.UserName,
                Password= user.Password,
                UpdatedBy = user.UpdatedBy,
                UpdatedOn = user.UpdatedOn,
            };


            // Return Ok response
            return Ok(userDTO);
        }


    }
}
