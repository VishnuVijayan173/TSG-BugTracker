﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BugProject.Domain.Repositories
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task<IEnumerable<TEntity>> GetAllAsync();

        Task<TEntity> GetAsync(Guid id);

        Task<TEntity> AddAsync(TEntity entity);

        Task<TEntity> DeleteAsync(Guid id);

        
    }
}
