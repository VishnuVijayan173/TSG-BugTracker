﻿
namespace BugProject.Domain.Entities
{
    public class Bug
    {
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Guid StatusID { get; set; } 
        public DateTime CreatedOn { get; set; }
      
        public DateTime UpdatedOn { get; set; }
    }
}
