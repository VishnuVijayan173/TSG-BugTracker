﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class ProjectAllocationRepository : Repository<ProjectAllocation>, IProjectAllocationRepository
    {
        private readonly AppDbContext appDbContext;

        public ProjectAllocationRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public async Task<ProjectAllocation> UpdateAsync(Guid id, ProjectAllocation projectAllocation)
        {
            var existingProjectAllocation = await appDbContext.ProjectAllocations.FirstOrDefaultAsync(x => x.AllocationID == id);

            if (existingProjectAllocation == null)
            {
                return null;
            }

            existingProjectAllocation.ProjectID = projectAllocation.ProjectID;
            existingProjectAllocation.UserID = projectAllocation.UserID;
            existingProjectAllocation.UpdatedOn = projectAllocation.UpdatedOn;
            existingProjectAllocation.UpdatedBy = projectAllocation.UpdatedBy;
            //existingBug.AssignedTo = bug.AssignedTo;
            //existingBug.UpdatedBy = bug.UpdatedBy;

            await appDbContext.SaveChangesAsync();

            return existingProjectAllocation;
        }
    }
}
