﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class BugRepository : Repository<Bug>, IBugRepository
    {
        private readonly AppDbContext appDbContext;

        public BugRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<Bug> UpdateAsync(Guid id, Bug bug)
            {
                var existingBug = await appDbContext.Bugs.FirstOrDefaultAsync(x => x.BugID == id);

                if (existingBug == null)
                {
                    return null;
                }
            existingBug.BugName = bug.BugName;
            existingBug.BugDescription = bug.BugDescription;
            existingBug.StatusID = bug.StatusID;
            existingBug.UpdatedOn = bug.UpdatedOn;
            

            await appDbContext.SaveChangesAsync();

                return existingBug;
        }
     }
}