﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class RoleRepository : Repository<Role>, IRoleRepository
    {
        private readonly AppDbContext appDbContext;

        public RoleRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public async Task<Role> UpdateAsync(Guid id, Role role)
        {
            var existingRole = await appDbContext.Roles.FirstOrDefaultAsync(x => x.RoleID == id);

            if (existingRole == null)
            {
                return null;
            }

            existingRole.RoleName = role.RoleName;
            existingRole.UpdatedBy = role.UpdatedBy;
            existingRole.UpdatedOn = role.UpdatedOn;
            //existingBug.AssignedTo = bug.AssignedTo;
            //existingBug.UpdatedBy = bug.UpdatedBy;

            await appDbContext.SaveChangesAsync();

            return existingRole;
        }
    }
}
