﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        private readonly AppDbContext appDbContext;

        public UserRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public async Task<User> UpdateAsync(Guid id, User user)
        {
            var existingUser = await appDbContext.Users.FirstOrDefaultAsync(x => x.UserID == id);

            if (existingUser == null)
            {
                return null;
            }

            existingUser.UserName = user.UserName;
            existingUser.Password = user.Password;
            existingUser.RoleID = user.RoleID;
            existingUser.UpdatedBy = user.UpdatedBy;
            existingUser.UpdatedOn = user.UpdatedOn;

            await appDbContext.SaveChangesAsync();

            return existingUser;
        }
    }
}
