﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class StatusRepository : Repository<Status>, IStatusRepository
    {
        private readonly AppDbContext appDbContext;

        public StatusRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<Status> UpdateAsync(Guid id, Status status)
        {
            var existingStatus = await appDbContext.Statuses.FirstOrDefaultAsync(x => x.StatusID == id);

            if (existingStatus == null)
            {
                return null;
            }

            existingStatus.BugStatus = status.BugStatus;
            existingStatus.UpdatedOn = status.UpdatedOn;
            existingStatus.UpdatedBy = status.UpdatedBy;

            await appDbContext.SaveChangesAsync();

            return existingStatus;
        }
    }
}
