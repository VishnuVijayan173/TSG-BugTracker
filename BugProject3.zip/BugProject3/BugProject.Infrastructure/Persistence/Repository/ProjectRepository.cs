﻿using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class ProjectRepository : Repository<Project>, IProjectRepository
    {
        private readonly AppDbContext appDbContext;

        public ProjectRepository(AppDbContext appDbContext) : base(appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<Project> UpdateAsync(Guid id, Project project)
        {
            var existingProject = await appDbContext.Projects.FirstOrDefaultAsync(x => x.ProjectID == id);

            if (existingProject == null)
            {
                return null;
            }

            existingProject.ProjectName = project.ProjectName;
            existingProject.ProjectDetails = project.ProjectDetails;
            existingProject.UpdatedOn = project.UpdatedOn;
            existingProject.UpdatedBy = project.UpdatedBy;

            await appDbContext.SaveChangesAsync();

            return existingProject;
        }
    }
}
