﻿namespace BugProject.Infrastructure.Persistence.DTO
{
    public class Role
    {
        public Guid RoleID { get; set; }
        public string RoleName { get; set; }

        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
