﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class AddStatusRequest
    {
        public Guid StatusID { get; set; }
        public string BugStatus { get; set; }
        public DateTime UpdatedOn { get; set; }

        public Guid UpdatedBy { get; set; }
    }
}
