﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class AddProjectRequest
    {
        public Guid ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDetails { get; set; }
        public DateTime UpdatedOn { get; set; }
        public Guid UpdatedBy { get; set; }
    }
}
