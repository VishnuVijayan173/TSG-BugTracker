﻿using System;
namespace BugProject.Infrastructure.Persistence.DTO
{
    public class UpdateBugRequest
    {
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Guid StatusID { get; set; }
       // public Guid AssignedTo { get; set; }
       // public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
