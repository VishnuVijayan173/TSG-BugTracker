﻿namespace BugProject.Infrastructure;
public class Class1
{

}
