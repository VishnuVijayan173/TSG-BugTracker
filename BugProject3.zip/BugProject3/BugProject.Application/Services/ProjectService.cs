﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class ProjectService : IProjectService
    {
        private readonly IProjectRepository projectRepository;
        public ProjectService(IProjectRepository projectRepository)
        {
            this.projectRepository = projectRepository;
        }
        public async Task<IEnumerable<Domain.Entities.Project>> GetAllAsync()
        {
            return await projectRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.Project> GetAsync(Guid id)
        {
            return await projectRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.Project> AddAsync(Domain.Entities.Project project)
        {
            return await projectRepository.AddAsync(project);
        }
        public async Task<Domain.Entities.Project> DeleteAsync(Guid id)
        {
            return await projectRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.Project> UpdateAsync(Guid id, Domain.Entities.Project project)
        {
            return await projectRepository.UpdateAsync(id, project);
        }
    }
}
