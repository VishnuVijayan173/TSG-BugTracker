﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class ProjectAllocationService : IProjectAllocationService
    {
        private readonly IProjectAllocationRepository projectAllocationRepository;
        public ProjectAllocationService(IProjectAllocationRepository projectAllocationRepository)
        {
            this.projectAllocationRepository = projectAllocationRepository;
        }
        public async Task<IEnumerable<Domain.Entities.ProjectAllocation>> GetAllAsync()
        {
            return await projectAllocationRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.ProjectAllocation> GetAsync(Guid id)
        {
            return await projectAllocationRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.ProjectAllocation> AddAsync(Domain.Entities.ProjectAllocation projectAllocation)
        {
            return await projectAllocationRepository.AddAsync(projectAllocation);
        }
        public async Task<Domain.Entities.ProjectAllocation> DeleteAsync(Guid id)
        {
            return await projectAllocationRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.ProjectAllocation> UpdateAsync(Guid id, Domain.Entities.ProjectAllocation projectAllocation)
        {
            return await projectAllocationRepository.UpdateAsync(id, projectAllocation);
        }
    }
}
