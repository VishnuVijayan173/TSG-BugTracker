﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository roleRepository;
        public RoleService(IRoleRepository roleRepository)
        {
            this.roleRepository = roleRepository;
        }
        public async Task<IEnumerable<Domain.Entities.Role>> GetAllAsync()
        {
            return await roleRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.Role> GetAsync(Guid id)
        {
            return await roleRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.Role> AddAsync(Domain.Entities.Role role)
        {
            return await roleRepository.AddAsync(role);
        }
        public async Task<Domain.Entities.Role> DeleteAsync(Guid id)
        {
            return await roleRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.Role> UpdateAsync(Guid id, Domain.Entities.Role role)
        {
            return await roleRepository.UpdateAsync(id, role);
        }
    }
}
