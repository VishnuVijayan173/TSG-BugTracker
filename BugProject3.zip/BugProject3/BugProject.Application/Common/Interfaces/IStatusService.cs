﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IStatusService
    {
        Task<IEnumerable<Status>> GetAllAsync();

        Task<Status> GetAsync(Guid id);

        Task<Status> AddAsync(Status status);

        Task<Status> DeleteAsync(Guid id);

        Task<Status> UpdateAsync(Guid id, Status status);
    }
}
