﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Mappings.Profiles
{
    public class BugProfile : Profile
    {
        public BugProfile()
        {
            CreateMap< BugProject.Domain.Entities.Bug, BugProject.Infrastructure.Persistence.DTO.Bug>()
                .ReverseMap();
        }
    }
}
